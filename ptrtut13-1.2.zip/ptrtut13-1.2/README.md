# ptrtut13
A TUTORIAL ON POINTERS AND ARRAYS IN C

This is A TUTORIAL ON POINTERS AND ARRAYS IN C Version 1.2 by Ted Jensen. I am putting this up on my Github account as it appears that Ted has taken down his website where this tutorial was located. I find this tutorial on pointers in C to be one of the best out there and well worth preserving. Since Ted also put this in the Public Domain I plan on working on the tutorial to remove any links to his defunct website and point them to this repository. I also plan on cleaning up the tutorial a bit to remove a few 1990's references (when this turtorial was written) and if needed, update any code to the C11 standard.

The first commit will be exactly as ver. 1.2 of his tutorial was on his website before it was deleted.
All future updates with be ver 1.3 and be protected under version 3 of the General Public License. 
